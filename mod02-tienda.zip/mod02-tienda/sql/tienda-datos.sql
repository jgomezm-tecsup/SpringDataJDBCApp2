INSERT INTO CATEGORIAS (ID, NOMBRE, ORDEN ) VALUES (1,'Procesadores',1) ;
INSERT INTO CATEGORIAS (ID, NOMBRE, ORDEN ) VALUES (2,'Memorias', 2) ;
INSERT INTO CATEGORIAS (ID, NOMBRE, ORDEN ) VALUES (3,'Discos Duros', 3);

INSERT INTO PRODUCTOS VALUES (1,1,'Intel Core I7','Procesador Intel Core I7-8700 Lga 1151 8va',1479.99,6, null, null, null, null, 1) ;
INSERT INTO PRODUCTOS VALUES (2,2,'Kingstone','Kingstone 64GB DDR3',80.00,12, null, null, null, null, 1) ;
INSERT INTO PRODUCTOS VALUES (12,1,'ihpone 9','Iphone ',2000.00,6, null, null, null, null, 1) ;
INSERT INTO PRODUCTOS VALUES (16,1,'Amd','Procesador AMD ',223.00,12, null, null, null, null, 1) ;

-- SELECT  * FROM CATEGORIAS;
-- SELECT  * FROM PRODUCTOS;